C - Hash tables
In this project, I learned about hashing by implementing hash functions and hash tables in C.
