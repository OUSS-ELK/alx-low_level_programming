#ifndef SUM_H
#define SUM_H

#define SUM(x, y) ((x) + (y))

#endif
