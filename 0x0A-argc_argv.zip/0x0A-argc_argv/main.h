#ifndef MAIN_H
#define MAIN_H

int _putchar(char c);
int _atoi(char *s);

#endif
